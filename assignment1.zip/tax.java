import java.util.Scanner;
public class tax {
    public static void main(String[] args){
        int yr,age;
        float t=0,sal,sa;
        String name;
        Scanner s= new Scanner(System.in);
        System.out.println("enter the name, DOB year, monthly salary:");
        name=s.next();
        yr= s.nextInt();
        sal=s.nextInt();

        age=2020-yr;
        sa=sal*12;

        if( sa>= 500000)
            t = (float) (0.2* sa);
        else if(sa>=400000 && sa<500000)
            t=(float)(0.15 * sa);
        else if(sa>=300000 && sa<400000)
            t= (float) (0.10 * sa);
        else if(sa>=200000&& sa<300000)
            t= (float) (0.5*sa);

        System.out.println("name:\t"+name+"\n age:\t"+ age+"\n annual salary:\t"+sa+"\nthe tax amount:\t"+t);
    }
}
