import java.util.Scanner;
public class percent {
    public static void main(String[] args) {
        float n1, n2, n3, n4, n5,m,p;
        Scanner s = new Scanner(System.in);
        System.out.println("enter 5 subject marks");

        n1 = s.nextInt();
        n2 = s.nextInt();
        n3 = s.nextInt();
        n4 = s.nextInt();
        n5 = s.nextInt();
        m=n1+n2+n3+n4+n5;
        p = (m/500)*100;

    System.out.println("percentage=" + p);
    }
}
