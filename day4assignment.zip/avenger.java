import java.util.Scanner;
public class avenger {

    String name,weapon,power,planet;
    int age;
    void getDetails()
    {
        Scanner s=new Scanner(System.in);
        System.out.println("enter name,age,power,weapon and planet");
        name=s.next();
        age= s.nextInt();
        power=s.next();
        weapon=s.next();
        planet=s.next();
    }
    void displayDetails()
    {
        System.out.println("name:"+name+"\nage:"+age+"\npower:"+power+"\nweapon:"+weapon+"\nplanet":+planet);
    }
}

